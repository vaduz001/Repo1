﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment1
{
    public partial class formlab1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Btnsubmit_Click(object sender, EventArgs e)
        {
            // This code fires when the user clicks the button
            Results.Visible = true;

            

           //*** NOTE I UNDERSTAND THAT INTEGERS CAN BE USED INSTEAD OF DECIMALS (EXCEPT FOR DIVISION) HOWEVER I FEEL THAT UPDATING THIS APP IN THE FUTURE MAY BE EASIER IF DATA IS IN DECIMALS (INCASE AWARDING HALF A WIN FOR AN OVERTIME LOSS)

          
            decimal ttlgames = 4; // total number of games

            decimal Sgame1 = Convert.ToInt32(txtScored1.Text); // convert text data of input for goals from game 1 to decimal
            decimal Sgame2 = Convert.ToInt32(txtScored2.Text); // convert text data of input for goals from game 2 to decimal
            decimal Sgame3 = Convert.ToInt32(txtScored3.Text); // convert text data of input for goals from game 3 to decimal
            decimal Sgame4 = Convert.ToInt32(txtScored4.Text); // convert text data of input for goals from game 4 to decimal

            decimal Agame1 = Convert.ToInt32(txtAllowed1.Text); // convert text data of input for goals allowed for game 1 to decimal
            decimal Agame2 = Convert.ToInt32(txtAllowed2.Text); // convert text data of input for goals allowed for game 2 to decimal
            decimal Agame3 = Convert.ToInt32(txtAllowed3.Text); // convert text data of input for goals allowed for game 3 to decimal
            decimal Agame4 = Convert.ToInt32(txtAllowed4.Text); // convert text data of input for goals allowed for game 4 to decimal

            decimal ttlSpec1 = Convert.ToInt32(txtSpec1.Text); // convert text data of input for spectators of game 1 to decimal
            decimal ttlSpec2 = Convert.ToInt32(txtSpec2.Text); // convert text data of input for spectators of game 2 to decimal
            decimal ttlSpec3 = Convert.ToInt32(txtSpec3.Text); // convert text data of input for spectators of game 3 to decimal
            decimal ttlSpec4 = Convert.ToInt32(txtSpec4.Text); // convert text data of input for spectators of game 4 to decimal

            
            int results1 = 0; //assign default variable to zero of game 1
            // run loop for game 1 to see if listitem is selected.. 
            foreach (ListItem listItem in RblWL1.Items)
            {
                
                if (listItem.Selected)
                {
                    // update results1 If selected convert value of selection (win = 1, loss =0) to integer and assign to variable 1 
                     results1 = Convert.ToInt32(listItem.Value);                                                                            
                }
                else
                {                 
                }
            }

            int results2 = 0; //assign default variable to zero of game 2

            foreach (ListItem listItem in RblWL2.Items)
            {
                if (listItem.Selected)
                {
                    // update results2 If selected convert value of selection (win = 1, loss =0) to integer and assign to variable 2 
                    results2 = Convert.ToInt32(listItem.Value);               
                }
                else
                {
                }
            }

            int results3 = 0; //assign default variable to zero of game 3

            foreach (ListItem listItem in RblWL3.Items)
            {
                if (listItem.Selected)
                {
                    // update results3 If selected convert value of selection (win = 1, loss =0) to integer and assign to variable 3
                    results3 = Convert.ToInt32(listItem.Value);                    
                }
                else
                {
                }
            }

            int results4 = 0; //assign default variable to zero of game 4

            foreach (ListItem listItem in RblWL4.Items)
            {

                if (listItem.Selected)
                // update results4 If selected convert value of selection (win = 1, loss =0) to integer and assign to variable 4 
                {
                    results4 = Convert.ToInt32(listItem.Value);                   
                }
                else
                {
                }
            }

            decimal games = (results1 + results2 + results3 + results4); // assign values to decimal variable of results 1 to 4.
            string wins = games.ToString(); //convert total value to string variable which is the total amount of wins             
            decimal lossage = (ttlgames - games); // total number of games - games won.
            decimal perc = (games / ttlgames) * 100 ; // percentage of games won games divided by total number of games multiplied by 100
            decimal pFor = (Sgame1 + Sgame2 + Sgame3 + Sgame4); //Adding all the inputs for Goals scored from each game
            decimal pAgainst = (Agame1 + Agame2 + Agame3 + Agame4); //Adding all the inputs for goals allowed from each game
            decimal pDif = (pFor - pAgainst);// GOALS FOR MINUS GOALS ALLOWED is the differential variable (pDif)
            decimal tSpec = (ttlSpec1 + ttlSpec2 + ttlSpec3 + ttlSpec4); // adding all the spectators from each game
            decimal aSpec = (tSpec / ttlgames); // dividing total number of spectators by number of games


            lblWins.Text = "you had: " + wins + " wins"; // assigning number of wins to output text
            lblLoss.Text = "you had: " + lossage + " lossses"; // assigning number of losses to output text
            lblPerc.Text = " The Win Loss Ratio was: " + perc + "%"; // assigning win percentage to output text
            lblPointDif.Text = "The total Goal Differential is: " + pDif; // assigning goal differential output text 
            lblScored.Text = "total goals scored:" + (pFor); // assigning number of goals scored to output text
            lblAllowed.Text = "Total allowed Goals:" + (pAgainst); // assigning number of goals allowed to output text
            lblTtlSpec.Text = "Total Spectators: " + tSpec; // assigning number of total spectators to output text
            lblAvgSpec.Text = "Average Spectators per game: " + aSpec; // assigning number of average spectators to output text
            
           
        }
    }
}


            